---
name: "yt-script"
description: "Turn one idea into a YouTube script someone finishes, with five scored hook options. Use for \"write a script\", \"hook ideas\", \"script this video\"."
---

# yt-script

One idea into a script somebody finishes.

## Before you write

1. If the user has a voice profile saved (e.g. `~/.claude/youtube/voice.md`), read it: how they talk on camera, words they never use, who they are talking to, what they will not claim. If none exists, ask for three of their own videos, infer the voice, and offer to save it.
2. Never invent a number, a result or a source. If a figure would strengthen it and you do not have one, ask for it or write the line without it.

## The shape

**The first 15 seconds is the whole job.** It does three things or the video leaks: confirm the click the title promised, open a question the viewer cannot close, and prove the payoff exists.

1. **Hook.** Write FIVE different hooks (curiosity gap, bold claim, specific number, stakes, contradiction, story-in-medias-res, etc.). Score each 1-10 on: specificity, open loop, promise-of-payoff, brevity (under ~20 words). Keep the top two and show both with their scores. Never hand over one hook.
2. **The turn** (0:15-0:45). Say what the video is going to do, in one sentence, and start doing it. No channel intro, no "before we get started", no subscribe pitch.
3. **The body.** One idea per beat. Mark each beat with what is ON SCREEN, not just what is said.
4. **The payoff.** Deliver the thing the hook promised, explicitly, and say that you are delivering it.
5. **The close.** One ask. Not three.

## What to hand back

- the two best hooks with their scores
- the script, beat by beat, with `[ON SCREEN: ...]` on every beat
- the runtime estimate at 150 words per minute
- one line naming which hook formula won and why it fits this idea

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**