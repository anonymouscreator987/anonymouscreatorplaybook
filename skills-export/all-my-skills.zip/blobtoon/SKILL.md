---
name: "blobtoon"
description: "Use when the user says 'Blobtoon' or asks for a funny animated deadpan blob-character short (9:16) explaining a weird fact, in the style of the @Haminations 'I'm so in shape' reference."
---

# Blobtoon

User-named style: when the user says "make this in Blobtoon: <topic>", produce a 30-65s vertical (1080x1920, 30fps) animated skit. Do not make an informational explainer; make a comedy skit where the fact is the punchline.

## Look
- Thick near-black outlines (#1b1424), flat fills, big blob heads, noodle arms, tiny/stub legs.
- SVG feTurbulence/feDisplacementMap "boil" (4 seeds cycling every 3 frames), film grain overlay, soft vignette, subtle handheld jitter.
- Flat simple backgrounds (palace, lab, court, reef, space, desert, street, tomb...).
- Captions: Comic Neue 700, 1-3 word pop-spring chunks, thick black stroke, per-speaker colour, at y~1470.
- Faces are parametric and EMOTIONAL: eyes dot<->sclera, lids, brows, mouth corners/open/teeth, blush, sweat, tears, special eyes (^^, > <, spirals, hearts, X). Each line has an emotion for the speaker (use 'a>b' to switch mid-line) and optional reactions for listeners. Non-speakers look toward the speaker. Brows pop on stressed words. Emotion changes trigger small hops/shakes and a cartoon SFX.

## Physics
Per-character spring rig: every spoken word is an impulse (squash/stretch, hop, tilt, arm swing); scripted hops/kicks on gags; camera has spring zoom + shake on impacts; ballistic arcs for thrown props; entrances with damped springs.

## Humor rules
- Hook in the first 2 seconds (a provocative line or a visual gag), no intro.
- Two or three characters, deadpan literal dialogue, one fact per beat, escalate, end on a short puncher then a ba-dum / sad trombone.
- Never recite facts like a documentary; characters argue, flex, or are embarrassed by the fact.
- Verify the fact before scripting.

## Audio
- NO background music. Cartoon recorded SFX (boing, splat, wet towel, bonk, spring, scratch, swallow, bell, win jingle) placed on every action, cut (swish), entrance and emotion change.
- Voices: human-sounding TTS (Chatterbox voice-cloning from distinct reference clips per character, or ElevenLabs if the user provides a key). Pitch-shifted refs for creatures. Duck SFX under voice, loudnorm -14 LUFS.

## Pipeline (Remotion + Python)
1. Write a story module: CAST (spec, voice ref, colour) and SHOTS (bg, cast with positions/entrances, lines as (id, who, text, emotion, opts), props with keyframes/pop, fx list like ('E:id+0.1','boom')).
2. Generate voices, align words with faster-whisper, build timeline, rig, emotion keyframes, SFX mix, plan.json.
3. Render with Remotion at scale 0.6667 (720x1280), crf 24; render takes ~10-20 min so run it in the background and poll.
4. Deliver the mp4 under 30MB with a one-line summary.

The engine code lives in the session workspace; if absent, rebuild it following the above.