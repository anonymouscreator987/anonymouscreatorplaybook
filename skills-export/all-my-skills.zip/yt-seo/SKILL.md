---
name: "yt-seo"
description: "Write YouTube titles-adjacent SEO: descriptions, tags and the search-query test for a video. Use for \"write the description\", \"tags for this video\", \"SEO this video\"."
---

# yt-seo

Search is a smaller lever than packaging and a bigger one than people think for evergreen videos. For a video aimed at the subscriber feed, say so and spend the effort on the title and thumbnail instead.

## Before you write

1. If the user has a voice profile saved (for example `~/.claude/youtube/voice.md`), read it: how they talk on camera, the words they never use, who they are talking to, what they will not claim. If none exists, ask for three of their own videos, infer the voice, and offer to save it.
2. Never invent a number, a result or a source. If a figure would strengthen it and you do not have one, ask for it or write the line without it.

## The description

- **The first two lines are the only ones anyone reads.** They show above "...more" and they are the search snippet. Say what the video gives them, in the words they would have typed.
- Then the link or the resource, if there is one, so it is above the fold.
- Then chapters.
- Then the long version: what is covered, who it is for, what it assumes.

## Tags, honestly

Tags are a weak signal and YouTube has said so. Use them for disambiguation - spellings, the tool names, the abbreviations people actually type - and stop. Fifteen is plenty. A wall of tags is not a strategy and stuffing unrelated ones is against the terms.

## The query test

Before handing anything over, write the three search queries this video should win, and check the title and first two description lines contain the words in those queries. If they do not, the problem is the title, not the description.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**