---
name: "yt-chapters"
description: "Write valid YouTube chapters from a timestamped transcript. Use for \"add chapters\", \"timestamps for this video\"."
---

# yt-chapters

Find chapter boundaries in a timestamped transcript by looking at pauses and shifts in vocabulary or topic, then write the list.

## The rules, which are not optional

A chapter list that breaks any of these silently does not become chapters at all - the block just sits in the description doing nothing:

- The first entry must be **00:00**.
- There must be **at least three**.
- Each must be **at least 10 seconds** long.

Check all three before handing the list over.

## Title every line

Title each chapter as the promise of that section, in the user's voice, three to five words. A chapter called "Thumbnails Titles Packaging" is a placeholder. Chapters are also a retention diagnostic: if a section cannot be named in five words, it is two sections or it is filler. Aim for roughly 8 chapters per 10 minutes unless the video suggests otherwise.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**