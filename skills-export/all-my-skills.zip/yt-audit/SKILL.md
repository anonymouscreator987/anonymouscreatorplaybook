---
name: "yt-audit"
description: "Audit a YouTube channel and end in ONE fix. Use for \"audit my channel\", \"why isn't my channel growing\"."
---

# yt-audit

An audit that lists twenty problems is a way of avoiding the one that matters. This ends in ONE fix.

## Before you write

1. If the user has a voice profile saved (e.g. `~/.claude/youtube/voice.md`), read it. If none exists, ask for three of their own videos and infer the voice.
2. Never invent a number, a result or a source.

## What to look at, in this order

1. **The last ten titles, as a set.** Read them as a list, the way the channel page shows them. Do they promise different things? A channel where every title is the same shape has a format problem, not a title problem. Check length (60 desktop / 40 mobile).
2. **The thumbnails, at feed size.** Shrink them. What survives? If three are unreadable at that size, that is the fix and nothing else matters yet.
3. **The first fifteen seconds of the three most recent videos.** Transcribe them and judge the hook: specific, open loop, promise of payoff. This is where most channels lose.
4. **Upload rhythm.** Not frequency - CONSISTENCY. Six videos in one week and then nothing for a month is worse than one a fortnight forever.
5. **The retention shape**, if they can export it.

## What to hand back

- The single biggest fix, named, with what to do this week.
- Three things that are already working, so they do not break them. Be specific; "your energy is good" is not an observation.
- What NOT to do yet, and why.

Never open an audit with praise you do not mean, and never end one with a list of twenty things.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**