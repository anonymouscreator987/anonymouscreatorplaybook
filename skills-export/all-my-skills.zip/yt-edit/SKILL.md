---
name: "yt-edit"
description: "Make an edit decision list (dead air, filler, repeats) from a timestamped transcript. Use for \"tighten this video\", \"find the cuts\", \"edit list\"."
---

# yt-edit

An edit decision list from a timestamped transcript. It prints the cuts. The user applies them.

No transcript yet? Ask for one, or produce one first (whisper, faster-whisper, or the caption track YouTube generates on an unlisted upload). Do not guess at timings.

## What to find

- **DEAD** - gaps longer than about 0.35 s, trimmed from the MIDDLE so both sides keep a breath. Cutting flush against speech makes a tightened take sound gasping.
- **FILLER** - cues that are nothing but "um", "so yeah", "basically".
- **REPEAT** - a sentence restarted. Compare against the last cue that was actually speech, not the literal previous cue, because most retakes have an "um" between the two attempts.

## What it will not do

It does not touch media and has no opinion about B-roll. A 40% cut is a 40% cut of SPEECH; if the video has a long silent demo, check the runtime against the footage.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**