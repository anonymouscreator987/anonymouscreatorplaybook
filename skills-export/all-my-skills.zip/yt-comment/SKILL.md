---
name: "yt-comment"
description: "Triage YouTube comments and write replies in the creator's voice. Use for \"reply to comments\", \"what should I pin\", \"triage my comments\"."
---

# yt-comment

The comment section is a retention surface, not a chore. Replies in the first few hours are what decide whether a thread becomes a conversation other people read.

## Before you write

1. If the user has a voice profile saved (e.g. `~/.claude/youtube/voice.md`), read it. If none exists, ask for three of their own videos or replies and infer the voice.
2. Never invent a number, a result or a source.

## Triage first, always

Sort what the user pastes into four piles and say how many are in each before writing anything:

1. **Questions** - answer them. These are the next video's topics, so note the repeats.
2. **Corrections** - if they are right, say so plainly and thank them. Never argue a fact you cannot check.
3. **Praise** - reply to a few, briefly, with something specific from their comment. A wall of identical "thank you!" replies reads as automated.
4. **Bait** - do not reply. Say so and move on. Never write a comeback, however deserved.

## Writing the reply

- Under 30 words. Answer the actual question in the first sentence.
- One question back, only when it is real.
- No emoji unless the user's own replies use them.
- Never promise a video the user has not agreed to make.

## The heart and the pin

Say which ONE comment to pin and why. Pin the question the most people also have, not the nicest one. Heart generously.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**