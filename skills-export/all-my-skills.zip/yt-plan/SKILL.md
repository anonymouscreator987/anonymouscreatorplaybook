---
name: "yt-plan"
description: "Build a realistic weekly YouTube content plan around hours available and what's already made. Use for \"content calendar\", \"plan my week\"."
---

# yt-plan

A plan that does not fit the week is a list of regrets. Ask two questions before writing anything: **how many hours do you actually have**, and **what is already half-made**.

## Before you write

1. If the user has a voice profile saved (e.g. `~/.claude/youtube/voice.md`), read it.
2. Never invent a number, a result or a source.

## The shape of a week (default; follow the user's own schedule if they have set one)

- **One anchor.** The video the week is for. It gets the most time and goes out on the day the channel's own analytics say is best - ask for that, do not assume a weekday.
- **One cheap one.** Built from something that exists: a clip, a reaction, a follow-up to the comment that got the most replies last week.
- **Shorts from the anchor.** Cut from the long video, not written separately.

The default is three uploads on a seven-day week, not seven; empty days are what make the filled ones survive a bad week. If the user has a heavier cadence, plan it but say honestly what it costs.

## What to hand back

A table: day, format, working title, the one sentence it promises, and what already exists for it. Then the honest line at the bottom - how many hours this costs, and what to drop first if the week goes wrong.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**