---
name: "yt-package"
description: "Write YouTube titles and thumbnail briefs as one unit and check them. Use for \"title ideas\", \"thumbnail\", \"package this video\"."
---

# yt-package

The title and the thumbnail are ONE unit. Writing them separately is why most packaging fails: the thumbnail repeats the title, and half the click surface says the same thing twice.

## Before you write

1. If the user has a voice profile saved (e.g. `~/.claude/youtube/voice.md`), read it. If none exists, ask for three of their own videos and infer the voice.
2. Never invent a number, a result or a source.

## Rules to check on every title (do the checks yourself and report them)

- **60 characters** is where desktop search truncates, **40** is a mobile home feed. Report both lengths: a desktop cut loses the tail, a mobile cut can lose the subject.
- **The thumbnail must not repeat the title.** Different words, same promise.
- **Three words maximum on the thumbnail.** At feed size a fourth word is a grey smear.
- **A number, a name or a date** beats every adjective available to you.
- **Two all-caps words is the ceiling** before a title reads as spam.

## Write ten, keep two

Generate ten titles, check them against the rules above, and show the user the top three with the specific issue on each. For the winner, write the thumbnail brief: the expression, the framing, the three words, and what the background has to do to hold contrast at feed size.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**