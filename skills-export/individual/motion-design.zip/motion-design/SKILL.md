---
name: "motion-design"
description: "Apply motion design principles (timing, easing, choreography, Disney principles) to UI animations, transitions, micro-interactions and motion graphics in any animation system."
---

# Motion Design Skill

Source: LottieFiles motion-design-skill (MIT). Condensed to the core SKILL.md.

## When to Apply

- Creating UI animations (buttons, cards, modals, page transitions)
- Micro-interactions and feedback animations
- Loading, success, or error states
- Animating illustrations or decorative elements
- Scroll-triggered or progress-based animations
- Establishing brand motion identity
- Choreographing multi-element sequences

**Decision tree:**
1. Functional purpose (feedback, guidance)? -> Timing rules for responsiveness
2. Expresses brand personality? -> Motion Personality archetypes
3. Tells a story or guides attention? -> Disney principles + choreography
4. Complex multi-element scene? -> 1/3 Rule + stagger patterns

## 8-Step Checklist

1. Emotional target? joy, calm, urgency, elegance
2. Motion personality? Playful, Premium, Corporate, Energetic
3. Primary property? position, scale, rotation, opacity
4. Duration? see table below
5. Easing family? entrance = decelerate, exit = accelerate
6. Hero element? apply staging
7. Secondary + ambient layers? add richness
8. 1/3 rules? motion distance, simultaneous elements

## Three Pillars (CRITICAL)

| Pillar | Question | Drives |
|---|---|---|
| Emotional Intent | What should the viewer FEEL? | Easing, timing, amplitude |
| Visual Narrative | What's the micro-story? | Setup -> Action -> Resolution |
| Motion Craft | How do we make it believable? | Physics, secondary motion, paths |

Three motion layers (flat animation = missing layers): Primary (main action), Secondary (shadows, icons shifting), Ambient (background gradients, subtle pulses).

## Motion Personality

Select ONE archetype per project and apply it consistently.

| Archetype | Duration | Easing | Overshoot | Keywords |
|---|---|---|---|---|
| Playful | 150-300ms | ease-out-back | 10-20% | fun, whimsical, bouncy, cute |
| Premium | 350-600ms | cubic-bezier(0.4,0,0.2,1) | 0% | elegant, minimal, luxury |
| Corporate | 200-400ms | cubic-bezier(0.2,0,0,1) | 0-3% | clean, professional, dashboard |
| Energetic | 100-250ms | ease-out-expo | 15-30% | dynamic, bold, exciting |

Default: Corporate for UI, Playful for illustrations. Brand motion identity = one signature easing for 80% of animations, three durations (quick/standard/slow), one consistent entrance pattern.

## Property Selection

| Effect Goal | Primary | Secondary |
|---|---|---|
| Entrance/Exit | position | opacity, scale |
| Emphasis | scale | subtle rotation, opacity pulse |
| State change | opacity, color | scale (press feedback) |
| Direction/Flow | position | rotation (follow path) |
| Depth/3D | scale + shadow | position (parallax) |
| Loading | rotation (spinner) | scale, opacity pulse |
| Success | scale (pop) | color, checkmark draw |
| Error/Alert | position (shake) | color, wobble |

Simplicity threshold: one property = direct, two = polished, three+ = potentially overwhelming.

## Duration Table

| Element | Duration |
|---|---|
| Tooltip / micro-feedback | 80-120ms |
| Button press / toggle | 120-180ms |
| Icon transition | 150-250ms |
| Card enter / exit | 200-350ms |
| Modal / dialog | 300-400ms |
| Page transition | 400-600ms |
| Dramatic reveal | 600-1200ms |

Distance scales duration: 100px = base, 200px = 1.3x, 400px = 1.6x. Entrances 30-50% longer than exits. Hover <100ms, press <150ms, release/settle 200-300ms, error shake 300-400ms (2-3 oscillations).

## Easing Selection

- Entrance -> decelerate (ease-out family)
- Exit -> accelerate (ease-in family)
- On-screen movement -> ease-in-out family
- Looping ambient -> sine-based ease-in-out

| Standard | Cubic Bezier | Use |
|---|---|---|
| Material Design 3 | (0.2, 0, 0, 1) | Default on-screen |
| MD3 Emphasized | (0.05, 0.7, 0.1, 1) | Entrances, attention |
| MD3 Accelerate | (0.3, 0, 1, 1) | Exits, dismissals |
| Apple HIG | (0.25, 0.1, 0.25, 1) | Standard iOS |
| Gentle float | (0.4, 0, 0.2, 1) | Ambient, background |
| Bounce settle | (0.175, 0.885, 0.32, 1.275) | Overshoot, playful |

Material-based: Rigid (metal/stone) 1.2x duration, 0% overshoot; Elastic (rubber/gel) 0.8x, 15-25%; Fluid (water/paint) 1.5x, 5%; Paper 1.0x, 3-5%; Gas (smoke/fog) 2.0x, 0%; Glass 0.9x, 0%.

## Common Patterns

Button press (Playful): anticipation scale 0.97 (50ms) -> squash [1.04, 0.96] (100ms) -> follow-through overshoot 1.02 settle 1.0 (spring, 200ms); shadow shrinks, icon shifts down 2px.

Card entrance (Premium): start 20px below, opacity 0; slight curved path (10px X offset at midpoint); ease-out-cubic; shadow arrives 50ms after card; content fades in 100ms after landing; other cards dim to 80%.

Success (Playful): scale pop with ease-out-back, checkmark draws in, subtle particle burst, green fill, 300-400ms.

Error shake (Corporate): 2-3 horizontal oscillations of +/-10-15px, ease-in-out, red tint, 300-400ms, no overshoot.

## Choreography Essentials

- Lead with the hero; all elements enter from the same direction; counter-motion: hero moves right -> ambient moves left at 20-30% speed.
- 1/3 Rule (distance): no motion travels more than 1/3 of the screen without a keyframe change.
- 1/3 Rule (elements): with 3+ elements, no more than 1/3 in active motion simultaneously.

| Stagger | Delay | Total budget | Use |
|---|---|---|---|
| Micro cascade | 20-40ms | <200ms | List items, grid cells |
| Standard | 50-100ms | <400ms | Cards, panels, nav |
| Dramatic | 100-200ms | <600ms | Hero sections |
| Wave | 30-60ms | <500ms | Data viz |

Total stagger must stay under 500ms (except dramatic).

## Emotion-to-Motion Map

| Emotion | Character | Path | Easing | Duration |
|---|---|---|---|---|
| Joy | Bouncy, arcs | Curved, upward | ease-out-back | 200-400ms |
| Calm | Smooth, flowing | Gentle curves | sine ease-in-out | 500-1000ms |
| Urgency | Sharp, fast | Straight lines | ease-out | 100-200ms |
| Sadness | Slow, downward | Drooping curves | cubic ease-in-out | 600-1200ms |
| Surprise | Sudden, expanding | Radial outward | ease-out-expo | 150-300ms |
| Elegance | Slow, controlled | Long arcs | (0.4,0,0.2,1) | 400-700ms |
| Playfulness | Bouncy, irregular | Arcs, squiggly | ease-out-back | 200-350ms |

Path as language: angular = tense, curved = friendly, spiral = whimsical, diagonal = purposeful, vertical = growth/weight, horizontal = progress.

## Weight Classification

| Weight | Examples | Duration | Overshoot |
|---|---|---|---|
| Heavy | Modals, overlays | 300-500ms | 0% |
| Medium | Cards, panels | 200-350ms | 3-5% |
| Light | Tooltips, badges, icons | 80-200ms | 5-15% |

## Quality Rules

CRITICAL: (1) never linear for spatial movement (only spinners/progress bars); (2) never opacity-only for important state changes; (3) never exceed 1/3 screen without an intermediate keyframe; (4) always three motion layers.

HIGH: match duration to element type; directional easing (ease-out entrance, ease-in exit); apply Disney principles (especially anticipation, follow-through); consistent personality across the scene.

## Troubleshooting

| Problem | Cause | Fix |
|---|---|---|
| Looks robotic | Linear easing or no arcs | Add easing curves + arc paths |
| Too slow | Duration too long for element | Check duration table, use ease-out |
| Cheap/flat | Missing secondary + ambient | Add shadow motion + background life |
| Distracting | Too many elements moving | Apply 1/3 rule, reduce amplitude |
| No personality | Generic easing everywhere | Apply a personality archetype consistently |