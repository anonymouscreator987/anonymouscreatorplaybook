---
name: "wangp-agent"
description: "Use when operating WanGP (Wan2GP): discover models, build settings, run video/image generation via its MCP server or Python API, poll jobs, and return output paths."
---

# WanGP Agent

Source: https://github.com/deepbeepmeep/Wan2GP (wangp-agent skill)

## Tool Choice

Prefer the WanGP MCP server when its tools are available. Use the in-process Python API when working inside the Wan2GP repository or when MCP is not connected. Use the CLI only as a fallback for existing queue JSON/ZIP files or one-off smoke tests.

Python API bootstrap:

```python
from shared.api import init

session = init(console_output=False)
```

MCP server command for local clients:

```bash
python wgp.py --mcp --config <config dir> --output-dir <output dir>
```

Use `python -m shared.mcp_server --root <WanGP repo> --output-dir <output dir>` only when a client needs the lower-level adapter entrypoint. `wgp.py --mcp` is preferred because it preserves normal WanGP CLI/config behavior.

## Discovery Workflow

1. List candidate models before generating. For a user-facing model name, call MCP `wangp_models(query=...)` first. Python: `session.list_model_metadata(query=...)`. Optional MCP filters are `name`, `family`, `base_model_type`, `finetune`, `model_type`, `main_output`, and `inputs`; string filters accept case-insensitive `*` and `?` globs.
2. Pick the model from its `capabilities`, `media_inputs`, `inputs`, `main_output`, and `outputs`.
3. `wangp_model` has only three views: `schema` (compact capabilities and limits, default), `definition` (parameter declarations), and `defaults` (generation settings). Use `definition` only when exact parameters or choices remain unclear. Compact servers preview long root strings; pass the exact root `property` named by a truncation suffix with the definition view to retrieve its full value.
4. Fetch defaults separately when building a raw generation request, and modify only the few settings needed. Preserve model-specific flags unless the user explicitly supplied an exact supported value. MCP: `wangp_model(model_type, view="defaults")`. Python: `session.get_default_settings(model_type)`. Use `wangp_model_settings(model_type)` to list saved settings, accelerator profiles and presets; pass a returned `setting_id` to read one.
5. If the request involves LoRAs, call `wangp_list_loras(model_type)` and copy returned identifiers exactly into `activated_loras`, with corresponding values in `loras_multipliers`.
6. Generate, then return artifact paths and any structured errors.

Read `wangp://docs/settings` when the task involves model selection, prompts, output dimensions, sampling, guidance, media inputs, acceleration or cache options, post-processing, sliding windows, LoRAs, or API setting metadata. For only `image_prompt_type`, `video_prompt_type`, or `audio_prompt_type`, prefer the smaller `wangp://docs/settings/prompt-flags` resource. Read resources through the client's standard MCP resource-reading capability.

For post-processing, call `wangp_postprocess(media_id=<media_id>)` without `process` to discover compatible operations (spatial upsampling, refiners such as face correction, temporal upscaling, soundtrack, voice replacement, audio editing). Then call it again with an exact returned process id and parameters; it runs through WanGP's normal generation queue.

For direct media utilities, call `wangp_toolbox()` without an action for a compact action list, then pass one action without `arguments` for its exact schema, then call it with `arguments`. Use `media_id` values returned by `wangp_list_gallery` for media arguments. Direct server paths must be inside the configured read scope.

For files, use the same discovery pattern with `wangp_io(action?, arguments?)`. Use `@alias/path` from its returned roots; plain paths use `@outputs`. In a final answer, directly reference valid Gallery media ids, unique Gallery filenames, or authorized file paths: WanGP turns them into inline download links, so do not call `download` only to create a link.

Use `wangp_artifact` (and read `wangp://skills/large-artifact-workflows`) when a collection exceeds about 10 items or ~2,048 payload tokens, or needs multi-pass revision. Long-form stories should also read `wangp://skills/long-form-story`. `action` and `arguments` are separate top-level tool parameters; never serialize the arguments object as text.

Use `wangp_notify(message, title?)` when the user asks to be notified.

## Media Input Rules

Use the entries in `metadata.media_inputs.image` to decide which image attachments can be supplied:

- `start`: set `image_start` and include `S` in `image_prompt_type`.
- `end`: set `image_end` and include `E` in `image_prompt_type`; combine with the source flag when needed, e.g. `SE`.
- `reference`: set `image_refs` and use a model-exposed `video_prompt_type` choice containing `I`.
- `single_reference`: `video_prompt_type` containing `I` and exactly one `image_refs` item.
- `multiple_references`: `video_prompt_type` containing `I` and multiple `image_refs` items.
- `background`: set `image_refs` and use a `video_prompt_type` containing `K`, normally with `I` (e.g. `KI`).
- `injected_frames`: set `image_refs` and `frames_positions`, with a `video_prompt_type` containing `F`.
- `control`: set `image_guide` with a `video_prompt_type` containing `V`; preserve accompanying preprocessing flags.
- `mask`: set `image_mask` with a `video_prompt_type` containing `A`; preserve accompanying mask/control flags.

Use `metadata.media_inputs.video` for `video_source`, `video_guide`, and `video_mask`. Use audio prompt files when `metadata.media_inputs.audio` contains `prompt`; never treat that as audio output. Audio output is indicated by `metadata.outputs` containing `audio` or `metadata.capabilities` containing `audio_output`.

Use `wangp_list_gallery` to discover existing session media (`selected_only=true` for live selections). Pass its `media_id` directly in generation, post-processing, and toolbox media fields. Call `wangp_get_media_settings(media_id=...)` only when full generation settings are needed. For remote HTTP servers, use `wangp_create_gallery_upload` for a short-lived PUT URL and `wangp_create_gallery_download(media_id=...)` for a GET URL (not available over stdio).

## Long Video Workflows

A long video is any sequence exceeding what the selected model should generate in one window. Call `wangp_model` and use `metadata.frames_maximum` as the max frame count per window or continuation call. Treat a larger `video_length` as a long-video workflow needing an explicit window plan; keep each window at or below `metadata.frames_maximum`; when `metadata.capabilities` contains `sliding_window`, one `video_length` request may span multiple windows.

The MCP/API accepts `video_length` as a seconds string such as `"10s"`; do not compute frames manually. Set numeric `force_fps` only when the user requests a specific FPS.

Prefer one planned sliding-window generation when the full sequence is known. Start from defaults, set `video_length` to the total, keep `sliding_window_size` <= `metadata.frames_maximum`. Set `multi_prompts_gen_type` to `W` for one non-empty prompt line per window or `PW` for one blank-line-separated paragraph per window. With `PW`, never put a blank line inside one window; use exactly one blank line between windows. Before calling `wangp_generate`, verify the paragraph count equals the intended window count (and the `image_end` count if used). Window prompts may be prefixed with commands:

- `[/duration=121]`, `[/duration=5s]`, `[/duration=20%]` sets that window's output length.
- `[/overlap=9]` overrides transition overlap; `[/overlap]` restores default.
- `[/overlap=0]` or `[/new_shot]` creates a hard cut when `text_to_video` is a capability.
- Combine, e.g. `[/duration=4s,/new_shot]`.

When `metadata.media_inputs.image` contains `end`, strongly prefer planned end-frame anchors to counter identity/appearance drift:

- Generate anchor images first with a suitable image model, consistent in character, clothing, environment and style.
- Prefer a master-image workflow: one high-quality master image, then one independent edit per planned keyframe, always from the same master `media_id` (never the previous edit). Collect outputs in chronological order.
- Provide ordered anchors through `image_end` (one per window), include `E` in `image_prompt_type` (`SE` with `image_start`).
- Align each window prompt with its end-frame target.
- If end frames are unavailable but `injected_frames` is supported, use `image_refs` + `frames_positions` with a `video_prompt_type` containing `F`.

Use repeated continuation when the next scene should be chosen after reviewing output: pass the latest generated video as `video_source`, include `V` in `image_prompt_type`, keep the new portion within `metadata.frames_maximum`, and submit another `wangp_generate`. The returned video already contains the source plus the continuation; use that combined output next time and do not re-merge. Repeated re-encoding gradually reduces quality. For transition behavior and frame-count formulas, read the Sliding Windows section of `wangp://docs/processing`.

## Generation

MCP generation is asynchronous by default:

```json
{
  "source": {
    "model_type": "example_model",
    "prompt": "A concise prompt",
    "image_mode": 0,
    "_api": {"return_media": true}
  }
}
```

Poll with `wangp_get_job(job_id)`. Use `wangp_cancel_job(job_id)` if the user asks to stop. For multiple requests in a row, keep the same MCP server or API session so model/runtime caches stay warm.

Some MCP clients expose tool results as JSON text instead of `structuredContent`. If `structuredContent` is empty, parse the first text content item as JSON before treating the call as failed.

Python generation:

```python
result = session.run_task(settings)
paths = result.generated_files
errors = [str(error) for error in result.errors]
```

Only request `_api.return_media`, `_api.return_video_uint8`, or `_api.return_audio` when in-memory tensors/audio are actually needed; artifact paths are usually enough.

## Practical Guardrails

Read the prompt-flag resource instead of composing unfamiliar flag strings by hand. Keep prompt enhancer off unless the user explicitly asks. Through MCP, prefer media IDs from `wangp_list_gallery`; use server filesystem paths only when the server permits them. For Python or CLI calls, resolve paths relative to the caller workspace or pass absolute paths. If validation or generation fails, surface the structured error instead of silently changing model or media inputs.

When writing settings JSON for WanGP, use UTF-8 without BOM. On Windows, set `PYTHONIOENCODING=utf-8` or keep report JSON ASCII-safe (`ensure_ascii=True`) when printing MCP event payloads; progress text can contain Unicode.