---
name: "yt-retention"
description: "Read a YouTube audience-retention export and name the single biggest leak. Use for \"why are people leaving\", \"analyze retention\", \"retention graph\"."
---

# yt-retention

The retention graph is the only honest feedback YouTube gives you. Almost nobody exports it.

Getting the file: Studio -> a video -> Analytics -> Engagement -> the audience-retention chart -> the download icon -> "Audience retention" (CSV). If the user also has a transcript, use it to say what was being said at each drop.

## Three different problems

- **HOOK LEAK** - what is lost in the first 30 seconds. Under 25% is healthy. This is always the first thing to fix and it is always the first fifteen seconds of script, never the edit.
- **CLIFFS** - single steep drops. A cliff is a moment: a topic change with no signposting, a sponsor read, a long setup. With a transcript, say what was said there.
- **SLIDE** - the steady bleed across the middle. A flat slide is pacing. The fix is cutting, not rewriting.

## What to hand back

Name the single biggest leak and one change for it. Not a list of five. Then, only if asked, the rest. If the hook leak is healthy and the slide is flat, say the video is fine and the problem is packaging (title and thumbnail).

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**