---
name: "yt-viral"
description: "Find which videos in a niche over-performed their own channel's median and why. Use for \"what's working in my niche\", \"outlier videos\", \"swipe file\"."
---

# yt-viral

Raw view counts rank channel size, not ideas. Rank by **multiple over each channel's own median**, which is the only version of the question that is about the video.

## Collecting the input

You need at least **four videos per channel** or a median means nothing; skip a channel with fewer and say so. Collect them from public listings (a channel's public Videos tab, or `yt-dlp --flat-playlist -J` against a channel URL), or a list the user pastes. Each row: channel, title, views, url, duration.

**Read, do not scrape.** Public listings only, never a logged-in session, never the user's account credentials.

## Computing

For each channel compute the median views, then each video's multiple = views / median. Keep videos at or above 2.0x.

## Reading the output

The multiple is the signal. The title-formula label (curiosity gap, number, stakes, contradiction, etc.) is a judgement about the TITLE - not a claim about why the video worked - and say so when you present it.

Hand back: the top five with their multiples, the formula each used, and the ONE structural thing they share. Then the harder line - which of those the user could actually make this week, in their voice, with what they have.

## The gate

Nothing here publishes. This skill writes and you publish. Every output ends in a block the user copies, and the last line of every run is the question: **ship it, or change it?**